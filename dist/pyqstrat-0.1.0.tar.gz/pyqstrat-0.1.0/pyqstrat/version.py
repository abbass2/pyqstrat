__version_info__ = (0, 1, 0)
__version__ = '.'.join(str(v) for v in __version_info__)
